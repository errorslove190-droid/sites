[CmdletBinding()]
param()
$ErrorActionPreference = 'Stop'
$python = Get-Command python.exe -ErrorAction SilentlyContinue
$claude = Get-Command claude.cmd -ErrorAction SilentlyContinue
if (-not $python -or -not $claude) {
    throw 'Python 3.10+ and Claude Code must already be installed. Nothing was installed or changed.'
}
$request = Join-Path $PSScriptRoot 'request.json'
if (-not (Test-Path -LiteralPath $request -PathType Leaf)) {
    throw 'Place request.json from Mikhail beside this script first.'
}
$report = Join-Path $PSScriptRoot ('review-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '.json')
Write-Host 'Claude will read only the supplied text packet. No model tools. Subscription limits apply.'
& $python.Source (Join-Path $PSScriptRoot 'team_bridge.py') review --request $request --out $report
if ($LASTEXITCODE -ne 0) { throw 'Review failed. No verified result. See STOP message above.' }
Write-Host "Send this report back to Mikhail: $report"
