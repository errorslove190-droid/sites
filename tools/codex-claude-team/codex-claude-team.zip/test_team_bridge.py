import copy
import json
import os
from pathlib import Path
import subprocess
import tempfile
import unittest
from unittest.mock import patch
import team_bridge as bridge


class BridgeTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name).resolve()
        (self.root / 'app.py').write_text('answer = 42\n', encoding='utf-8')
        self.packet = bridge.prepare(self.root, 'Проверить число', ['app.py'], 'code')
        self.review = dict(verdict='PASS', summary='Замечаний нет', findings=[],
                           suggested_tests=['Проверить 42'], limitations=['Статический анализ'])
        self.report = dict(version=1, packet_id=self.packet['id'], review=self.review)

    def test_roundtrip(self):
        self.assertEqual(bridge.check(self.packet, self.report, self.root)['verdict'], 'PASS')

    def test_invalid_top_level(self):
        with self.assertRaises(ValueError): bridge.validate([])
        with self.assertRaises(ValueError): bridge.check(self.packet, [], self.root)

    def test_cli_prepare_and_check(self):
        import sys
        script = str(Path(bridge.__file__).resolve())
        task = self.root / 'task.md'
        task.write_text('Проверить число', encoding='utf-8')
        packet_file = self.root / 'request.json'
        result = subprocess.run([sys.executable, script, 'prepare', '--project', str(self.root),
                                 '--task', str(task), '--include', 'app.py', '--kind', 'code',
                                 '--out', str(packet_file)], capture_output=True)
        self.assertEqual(result.returncode, 0, result.stderr)
        report_file = self.root / 'report.json'
        bridge.save_new(report_file, self.report)
        command = [sys.executable, script, 'check', '--project', str(self.root),
                   '--request', str(packet_file), '--report', str(report_file)]
        self.assertEqual(subprocess.run(command, capture_output=True).returncode, 0)
        (self.root / 'app.py').write_text('changed', encoding='utf-8')
        self.assertEqual(subprocess.run(command, capture_output=True).returncode, 1)

    def test_changed_source(self):
        (self.root / 'app.py').write_text('answer = 0', encoding='utf-8')
        with self.assertRaises(ValueError): bridge.check(self.packet, self.report, self.root)

    def test_wrong_report(self):
        self.report['packet_id'] = 'wrong'
        with self.assertRaises(ValueError): bridge.check(self.packet, self.report, self.root)

    def test_tampered_packet(self):
        self.packet['files']['app.py'] = 'changed'
        with self.assertRaises(ValueError): bridge.validate(self.packet)

    def test_unsafe_paths(self):
        for name in ['../app.py', '/app.py', 'C:/app.py', 'a\\b.py', '.env',
                     '.git/config', 'secrets/key.txt', 'passwords.txt', 'app.py:stream', 'pic.png']:
            with self.subTest(name=name), self.assertRaises(ValueError): bridge.safe_name(name)

    def test_secret_content(self):
        (self.root / 'key.txt').write_text('-----BEGIN RSA PRIVATE KEY-----')
        with self.assertRaises(ValueError): bridge.prepare(self.root, 'x', ['key.txt'], 'code')

    def test_size_limit(self):
        (self.root / 'big.txt').write_text('x' * (bridge.LIMIT + 1))
        with self.assertRaises(ValueError): bridge.prepare(self.root, 'x', ['big.txt'], 'code')

    def test_no_overwrite(self):
        target = self.root / 'request.json'
        bridge.save_new(target, self.packet)
        with self.assertRaises(FileExistsError): bridge.save_new(target, self.packet)

    def test_empty_task(self):
        with self.assertRaises(ValueError): bridge.prepare(self.root, ' ', ['app.py'], 'code')

    def test_no_files(self):
        with self.assertRaises(ValueError): bridge.prepare(self.root, 'x', [], 'code')

    def test_all_kinds(self):
        for kind in ['creative', 'mixed', 'code']:
            self.assertEqual(bridge.prepare(self.root, 'x', ['app.py'], kind)['kind'], kind)

    def test_conflicting_verdict(self):
        self.review['verdict'] = 'FIX'
        with self.assertRaises(ValueError): bridge.validate_review(self.review, self.packet)

    def test_unknown_file(self):
        self.review.update(verdict='FIX', findings=[dict(file='other.py', evidence='x', recommendation='y')])
        with self.assertRaises(ValueError): bridge.validate_review(self.review, self.packet)

    def test_valid_fix(self):
        self.review.update(verdict='FIX', findings=[dict(file='app.py', evidence='x', recommendation='y')])
        self.assertEqual(bridge.validate_review(self.review, self.packet)['verdict'], 'FIX')

    def test_blocked(self):
        self.review['verdict'] = 'BLOCKED'
        self.assertEqual(bridge.check(self.packet, self.report, self.root)['verdict'], 'BLOCKED')

    def test_mock_claude_no_tools_and_no_shell(self):
        status = subprocess.CompletedProcess([], 0, json.dumps(dict(loggedIn=True, authMethod='claude.ai')), '')
        result = subprocess.CompletedProcess([], 0, json.dumps(self.review), '')
        with patch.dict(os.environ, {}, clear=True), patch('team_bridge.shutil.which', return_value='claude'), \
             patch('team_bridge.subprocess.run', side_effect=[status, result]) as run:
            report = bridge.run_claude(self.packet)
            self.assertEqual(report['packet_id'], self.packet['id'])
            args, kwargs = run.call_args
            self.assertIn('--tools=', args[0])
            self.assertIn('--restricted', args[0])
            self.assertFalse(kwargs.get('shell', False))
            self.assertIn('DATA:', kwargs['input'])
            self.assertNotEqual(Path(kwargs['cwd']), self.root)

    def test_api_block_before_cli(self):
        with patch.dict(os.environ, {'ANTHROPIC_API_KEY': 'test'}), \
             patch('team_bridge.subprocess.run') as run, self.assertRaises(ValueError):
            bridge.run_claude(self.packet)
        run.assert_not_called()

    def test_logged_out(self):
        status = subprocess.CompletedProcess([], 0, '{"loggedIn":false}', '')
        with patch.dict(os.environ, {}, clear=True), patch('team_bridge.shutil.which', return_value='claude'), \
             patch('team_bridge.subprocess.run', return_value=status) as run, self.assertRaises(ValueError):
            bridge.run_claude(self.packet)
        self.assertEqual(run.call_count, 1)

    def test_timeout_does_not_return_report(self):
        status = subprocess.CompletedProcess([], 0, '{"loggedIn":true,"authMethod":"claude.ai"}', '')
        with patch.dict(os.environ, {}, clear=True), patch('team_bridge.shutil.which', return_value='claude'), \
             patch('team_bridge.subprocess.run', side_effect=[status, subprocess.TimeoutExpired('claude', 1)]), \
             self.assertRaises(subprocess.TimeoutExpired): bridge.run_claude(self.packet, timeout=1)

    def test_invalid_response(self):
        status = subprocess.CompletedProcess([], 0, '{"loggedIn":true,"authMethod":"claude.ai"}', '')
        bad = subprocess.CompletedProcess([], 0, 'I think PASS', '')
        with patch.dict(os.environ, {}, clear=True), patch('team_bridge.shutil.which', return_value='claude'), \
             patch('team_bridge.subprocess.run', side_effect=[status, bad]), self.assertRaises(ValueError):
            bridge.run_claude(self.packet)


if __name__ == '__main__':
    unittest.main()
